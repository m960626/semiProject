package com.example.mini.model;

public class TimeLine {
	private int tNo;
	private String tDate;
	private int cNo;
	private String tKind;
	private String id;
	private int mNo;
	private String name;
	private String nick;
	private String cNoH;
	private String cNoA;
	private String mDate;
	private String mTimeS;
	private String fName;
	
	public int gettNo() {
		return tNo;
	}
	public void settNo(int tNo) {
		this.tNo = tNo;
	}
	public String gettDate() {
		return tDate;
	}
	public void settDate(String tDate) {
		this.tDate = tDate;
	}
	public int getcNo() {
		return cNo;
	}
	public void setcNo(int cNo) {
		this.cNo = cNo;
	}
	public String gettKind() {
		return tKind;
	}
	public void settKind(String tKind) {
		this.tKind = tKind;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getmNo() {
		return mNo;
	}
	public void setmNo(int mNo) {
		this.mNo = mNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNick() {
		return nick;
	}
	public void setNick(String nick) {
		this.nick = nick;
	}
	public String getcNoH() {
		return cNoH;
	}
	public void setcNoH(String cNoH) {
		this.cNoH = cNoH;
	}
	public String getcNoA() {
		return cNoA;
	}
	public void setcNoA(String cNoA) {
		this.cNoA = cNoA;
	}
	public String getmDate() {
		return mDate;
	}
	public void setmDate(String mDate) {
		this.mDate = mDate;
	}
	public String getmTimeS() {
		return mTimeS;
	}
	public void setmTimeS(String mTimeS) {
		this.mTimeS = mTimeS;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
}
