package com.example.mini.model;

public class Guest {
	/* T2_GUSETB */
	private int gNo;
	private String id;
	private int mNo;
	private String gPosi1;
	private String gPosi2;
	private String gPosi3;
	private String gInfo;
	private String gStatYn;
	private String gStateYn;
	private String gDate;
	private String delyn;
	private String gAge;
	private String gTitle;
	private int gPCnt;
	private String fLoc;
	private String cName;
	private String cNoA;
	private String mTimeS;
	private String mTimeE;
	private String mAge;
	private String name;
	private String nick;
	private String mDate;
	private String cNoH;
	private String gcNo;
	private String gcDate;
	private String gcCont;
	private String gPosi;
	private String phone;
	private String getCnt;
	private int cnt;
	private int pageCnt;
	
	
	public int getgNo() {
		return gNo;
	}
	public void setgNo(int gNo) {
		this.gNo = gNo;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getmNo() {
		return mNo;
	}
	public void setmNo(int mNo) {
		this.mNo = mNo;
	}
	public String getgPosi1() {
		return gPosi1;
	}
	public void setgPosi1(String gPosi1) {
		this.gPosi1 = gPosi1;
	}
	public String getgPosi2() {
		return gPosi2;
	}
	public void setgPosi2(String gPosi2) {
		this.gPosi2 = gPosi2;
	}
	public String getgPosi3() {
		return gPosi3;
	}
	public void setgPosi3(String gPosi3) {
		this.gPosi3 = gPosi3;
	}
	public String getgInfo() {
		return gInfo;
	}
	public void setgInfo(String gInfo) {
		this.gInfo = gInfo;
	}
	public String getgStatYn() {
		return gStatYn;
	}
	public void setgStatYn(String gStatYn) {
		this.gStatYn = gStatYn;
	}
	public String getgDate() {
		return gDate;
	}
	public void setgDate(String gDate) {
		this.gDate = gDate;
	}
	public String getDelyn() {
		return delyn;
	}
	public void setDelyn(String delyn) {
		this.delyn = delyn;
	}
	public int getgPCnt() {
		return gPCnt;
	}
	public void setgPCnt(int gPCnt) {
		this.gPCnt = gPCnt;
	}
	public String getgAge() {
		return gAge;
	}
	public void setgAge(String gAge) {
		this.gAge = gAge;
	}
	public String getgTitle() {
		return gTitle;
	}
	public void setgTitle(String gTitle) {
		this.gTitle = gTitle;
	}
	public String getfLoc() {
		return fLoc;
	}
	public void setfLoc(String fLoc) {
		this.fLoc = fLoc;
	}
	public String getcName() {
		return cName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getGcNo() {
		return gcNo;
	}
	public void setGcNo(String gcNo) {
		this.gcNo = gcNo;
	}
	public String getGcDate() {
		return gcDate;
	}
	public void setGcDate(String gcDate) {
		this.gcDate = gcDate;
	}
	public String getGcCont() {
		return gcCont;
	}
	public void setGcCont(String gcCont) {
		this.gcCont = gcCont;
	}
	public String getgPosi() {
		return gPosi;
	}
	public void setgPosi(String gPosi) {
		this.gPosi = gPosi;
	}
	public String getcNoH() {
		return cNoH;
	}
	public void setcNoH(String cNoH) {
		this.cNoH = cNoH;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNick() {
		return nick;
	}
	public void setNick(String nick) {
		this.nick = nick;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getcNoA() {
		return cNoA;
	}
	public void setcNoA(String cNoA) {
		this.cNoA = cNoA;
	}
	public String getmTimeS() {
		return mTimeS;
	}
	public void setmTimeS(String mTimeS) {
		this.mTimeS = mTimeS;
	}
	public String getmTimeE() {
		return mTimeE;
	}
	public void setmTimeE(String mTimeE) {
		this.mTimeE = mTimeE;
	}
	public String getmAge() {
		return mAge;
	}
	public void setmAge(String mAge) {
		this.mAge = mAge;
	}
	public String getmDate() {
		return mDate;
	}
	public void setmDate(String mDate) {
		this.mDate = mDate;
	}
	public String getgStateYn() {
		return gStateYn;
	}
	public void setgStateYn(String gStateYn) {
		this.gStateYn = gStateYn;
	}
	public String getGetCnt() {
		return getCnt;
	}
	public void setGetCnt(String getCnt) {
		this.getCnt = getCnt;
	}
	public int getCnt() {
		return cnt;
	}
	public void setCnt(int cnt) {
		this.cnt = cnt;
	}
}
